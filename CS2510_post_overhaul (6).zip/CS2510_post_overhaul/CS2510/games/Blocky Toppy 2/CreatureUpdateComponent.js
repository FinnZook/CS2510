class CreatureUpdateComponent extends Component {

    




}