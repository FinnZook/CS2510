class Globals{

}
